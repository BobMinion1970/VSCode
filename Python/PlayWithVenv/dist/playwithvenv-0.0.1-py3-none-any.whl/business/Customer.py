class Customer():
    def __init__(self, id: str, last_name: str, first_name: str, account_id: int ): 
        self.id = id
        self.last_name = last_name
        self.first_name = first_name
        self.account_id = account_id